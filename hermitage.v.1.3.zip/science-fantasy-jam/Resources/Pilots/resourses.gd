extends Resource
class_name Files

@export_group("Stat Settings")
@export var heat: float = 0.0
@export var shields: float = 0.0
@export var mobility: float = 0.0
@export var power: float = 0.0
@export var scanners: float = 0.0

@export_group("Bot Settings")
@export var Head: float = 0.0
@export var Torso: float = 0.0
@export var Left_Arm: float = 0.0
@export var Left_Leg: float = 0.0
@export var Right_Arm: float = 0.0
@export var Right_Leg: float = 0.0

@export_group("Pilot Settings")
@export var pilot_name: String = ""
@export var ship_name: String = ""
@export var squadron: String = ""
@export var description: String = ""

@export_group("Textures")
@export var bot_texture: Texture2D
@export var icon_texture: Texture2D
