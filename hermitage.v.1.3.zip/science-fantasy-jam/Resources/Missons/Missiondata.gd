extends Resource
class_name Missions 

@export var heat: float = 0.0:
	set(value):
		heat = value
		emit_changed()

@export var shields: float = 0.0:
	set(value):
		shields = value
		emit_changed()

@export var mobility: float = 0.0:
	set(value):
		mobility = value
		emit_changed()

@export var power: float = 0.0:
	set(value):
		power = value
		emit_changed()

@export var scanners: float = 0.0:
	set(value):
		scanners = value
		emit_changed()

@export var base_suc_chance: float = 0.0
