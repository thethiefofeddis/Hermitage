class_name CardData
extends Resource

@export_group("Card Settings")
@export var card_name: String
@export_multiline var description: String
@export var cost: float
@export var card_texture: Texture2D
enum CardType { ATTACK, SKILL, POWER, MOVEMENT }
@export var type: CardType
enum Pilot_Only {All, Simon, Julia, Kaito}
@export var pilot: Pilot_Only

@export_group("Skill Settings")
@export var block: float
@export var fortify: float


@export_group("Movement Settings")
@export var movement: float
@export var distance: float

@export_group("Ataack Settings")
@export var damage: float
@export var risk: float

@export_group ("Armor Part")
enum armor_part {None, Head, Torso, Left_arm, Right_arm, Left_Leg, Right_Arm }
@export var All_Body: armor_part
@export var Simon_Body: armor_part
@export var Julia_Body: armor_part
@export var eAll_Body: armor_part
