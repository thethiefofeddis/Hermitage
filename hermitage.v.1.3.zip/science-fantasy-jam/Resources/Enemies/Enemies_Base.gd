class_name Enemy_Data
extends Resource

@export_group("Enemy Settings")
@export var enemy_name: String = ""
@export var ship_name: String = ""
@export var squadron: String = ""
@export var description: String = ""

@export_group("Enemy Settings DEBUG")
@export var max_health: float = 10.0
@export var current_health: float = 10.0
@export var speed: float = 100.0

@export_group("Bot Settings")
@export var Head: float = 0.0
@export var Torso: float = 0.0
@export var Left_Arm: float = 0.0
@export var Left_Leg: float = 0.0
@export var Right_Arm: float = 0.0
@export var Right_Leg: float = 0.0
