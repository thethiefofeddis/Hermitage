class_name SaveGame extends Resource

const SAVE_PATH := "user://savegame.tres"

@export var story_beat: String = ""
@export var Current_pilot_stats: Dictionary = {}
@export var Upgrades: Array = []
@export var player_name: String = ""
@export var pilot_name: String = ""

func debug_get_data() -> void:
	print("working")
	print("Player Name: ", GlobalData.main_name)
	print("Pilot Name: ", GlobalData.selected_pilot_name)
	
	GlobalData.get_pilot_stats() 
	print("All Pilots stats: ", GlobalData.pilot_stats_changed)
	print("Story beat: ", GlobalData.story_beat)

func save_game() -> void:
	var data = SaveGame.new()
	data.player_name = GlobalData.main_name
	data.pilot_name = GlobalData.selected_pilot_name
	data.story_beat = GlobalData.story_beat
	
	GlobalData.get_pilot_stats()
	data.Current_pilot_stats = GlobalData.pilot_stats_changed
	
	var error = ResourceSaver.save(data, SAVE_PATH)
	if error != OK:
		print("Failed to save game! Error code: ", error)
	else:
		print("Saved")

func load_game() -> void:
	if ResourceLoader.exists(SAVE_PATH):
		var data = ResourceLoader.load(SAVE_PATH, "", ResourceLoader.CACHE_MODE_REPLACE) as SaveGame
		if data:
			GlobalData.main_name = data.player_name
			GlobalData.selected_pilot_name = data.pilot_name
			GlobalData.story_beat = data.story_beat
			GlobalData.pilot_stats_changed = data.Current_pilot_stats
			GlobalData.name_changed.emit()
			GlobalData.pilot_changed.emit()
			GlobalData.story_beat_changed.emit()
			GlobalData.pilot_stats_updated.emit()
			print("Loaded player: ", GlobalData.main_name)
			print("Loaded pilot: ", GlobalData.selected_pilot_name)
			print("Loaded all pilot stats: ", GlobalData.pilot_stats_changed)
			print("Loaded story beat: ", GlobalData.story_beat)
	else:
		print("No save file found!")

func clear_save() -> void:
	if DirAccess.remove_absolute(SAVE_PATH) == OK:
		print("Save file successfully deleted.")
		GlobalData.main_name = "Juni"
		GlobalData.selected_pilot_name = "No Pilot Selected"
		GlobalData.story_beat = "0"
		GlobalData.pilot_stats_changed = {}
		GlobalData.name_changed.emit()
		GlobalData.pilot_changed.emit()
		GlobalData.story_beat_changed.emit()
		GlobalData.pilot_stats_updated.emit()
	else:
		print("Failed to delete save file, or no save file existed.")
