extends CharacterBody2D

signal enemy_spot_occupied(tile_position: Vector2i)
signal enemy_name(name_string: String)

@export var stats: Enemy_Data
@export var layer0: TileMapLayer
@export var layer1: TileMapLayer
@export var layer2: TileMapLayer
@export var attempt_value: float = 0
@export var hand_cards_data: Array[CardData] = []

var energy_this_turn: int = 3
var current_tile_pos: Vector2i = Vector2i.ZERO
var target_position: Vector2 = Vector2.ZERO
var is_moving: bool = false
var last_turn_observed: int = 0
var current_path: Array[Vector2i] = []
var is_playing_turn: bool = false

func _ready() -> void:
	input_pickable = true 
	if stats:
		stats = stats.duplicate()
	target_position = global_position
	last_turn_observed = GlobalData.current_turn_number
	if is_instance_valid(layer0):
		current_tile_pos = layer0.local_to_map(layer0.to_local(global_position))
		enemy_spot_occupied.emit(current_tile_pos)
		
	await get_tree().process_frame
	
	if GlobalData.movement_handler:
		if not GlobalData.movement_handler.spot_attacked.is_connected(_on_player_spot_attacked):
			GlobalData.movement_handler.spot_attacked.connect(_on_player_spot_attacked)


func _physics_process(_delta: float) -> void:
	if GlobalData.current_turn_number != last_turn_observed and not is_playing_turn:
		last_turn_observed = GlobalData.current_turn_number
		choose_random_spot()
		play_turn()
		reset_energy()

	if is_moving:
		move_to_target()

func is_cell_blocked_by_layers(cell: Vector2i) -> bool:
	if is_instance_valid(layer1) and layer1.get_cell_source_id(cell) != -1:
		return true
	if is_instance_valid(layer2) and layer2.get_cell_source_id(cell) != -1:
		return true
	return false

func find_bfs_path(start: Vector2i, target: Vector2i) -> Array[Vector2i]:
	if start == target:
		return [start]
	var used_cells = layer0.get_used_cells()
	if not used_cells.has(target):
		return []
	var occupied_tiles = {}
	var parent_node = get_parent()
	if parent_node and parent_node.has_method("get_occupied_tiles"):
		occupied_tiles = parent_node.get_occupied_tiles(self)
	var queue: Array = [ [start, [start]] ]
	var visited: Dictionary = { start: true }
	var directions = [Vector2i.UP, Vector2i.DOWN, Vector2i.LEFT, Vector2i.RIGHT]
	while queue.size() > 0:
		var current_element: Array = queue.pop_front()
		var current_cell: Vector2i = current_element[0]
		var path_so_far: Array = current_element[1]
		if current_cell == target:
			var final_path: Array[Vector2i] = []
			final_path.assign(path_so_far)
			return final_path
		for dir in directions:
			var neighbor = current_cell + dir
			if not visited.has(neighbor) and used_cells.has(neighbor):
				if occupied_tiles.has(neighbor) and neighbor != target:
					continue
				if is_cell_blocked_by_layers(neighbor):
					continue
				visited[neighbor] = true
				var new_path: Array = path_so_far.duplicate()
				new_path.append(neighbor)
				queue.append([neighbor, new_path])
	return []

func choose_random_spot() -> void:
	if not is_instance_valid(layer0) or is_moving:
		return
	var used_cells = layer0.get_used_cells()
	if used_cells.is_empty():
		return
	var parent_node = get_parent()
	var attempts = 0
	var max_attempts = attempt_value
	var random_cell: Vector2i = Vector2i.ZERO
	var valid_path: Array[Vector2i] = []
	while attempts < max_attempts:
		random_cell = used_cells[randi() % used_cells.size()]
		if is_cell_blocked_by_layers(random_cell):
			attempts += 1
			continue
		var is_target_occupied = false
		if parent_node and parent_node.has_method("is_tile_occupied"):
			is_target_occupied = parent_node.is_tile_occupied(random_cell, self)
		if not is_target_occupied:
			valid_path = find_bfs_path(current_tile_pos, random_cell)
			if not valid_path.is_empty():
				break
		attempts += 1
	if valid_path.is_empty():
		return
	current_path = valid_path.duplicate()
	current_path.pop_front()
	advance_path_movement()
	print("My goal is ", random_cell)

func advance_path_movement() -> void:
	if current_path.is_empty():
		is_moving = false
		enemy_spot_occupied.emit(current_tile_pos)
		return
	current_tile_pos = current_path.pop_front()
	target_position = layer0.to_global(layer0.map_to_local(current_tile_pos))
	is_moving = true
	print("I am on ", current_tile_pos)
	enemy_spot_occupied.emit(current_tile_pos)

func move_to_target() -> void:
	var direction = global_position.direction_to(target_position)
	velocity = direction * (stats.speed if stats else 100.0)
	move_and_slide()
	if global_position.distance_to(target_position) < 4.0:
		global_position = target_position
		velocity = Vector2.ZERO
		advance_path_movement()

func take_damage(amount: float) -> void:
	if not stats:
		return
	stats.current_health -= amount
	print("Health remaining: ", stats.current_health)
	if stats.current_health <= 0:
		print("Enemy defeated!")
		queue_free()

func _on_player_spot_attacked(attack_tile_position: Vector2i) -> void:
	if not is_instance_valid(layer0):
		return
	if current_tile_pos == attack_tile_position:
		take_damage(0.1)


func play_turn() -> void:
	if hand_cards_data.is_empty():
		print("I am pibble, give me cards in editor")
		return

	is_playing_turn = true
	var max_cards_to_play: int = randi_range(1, 3)
	var cards_played: int = 0
	var available_cards = hand_cards_data.duplicate()

	print("Enemy wants to play up to ", max_cards_to_play, " cards this turn.")

	while cards_played < max_cards_to_play and not available_cards.is_empty():
		var random_index: int = randi() % available_cards.size()
		var card_data: CardData = available_cards[random_index]
		var random_value: float = randf()

		if energy_this_turn >= card_data.cost and random_value > 0.5: 
			@warning_ignore("narrowing_conversion")
			energy_this_turn -= card_data.cost
			cards_played += 1
			hand_cards_data.erase(card_data)
			available_cards.remove_at(random_index)
			execute_card_logic(card_data)
			print("Enemy played card ", card_data.card_name, ", Energy left: ", energy_this_turn)
			await get_tree().create_timer(0.4).timeout
		else:
			available_cards.remove_at(random_index)
			
	is_playing_turn = false

func execute_card_logic(data: CardData) -> void:
	if data.type == CardData.CardType.MOVEMENT:
		GlobalData.movement_card_played.emit(data)
	elif data.type == CardData.CardType.ATTACK:
		GlobalData.attack_card_played.emit(data)
	elif data.type == CardData.CardType.SKILL:
		GlobalData.skill_card_played.emit(data)

func reset_energy() -> void:
	energy_this_turn = 3

func _input_event(_viewport: Viewport, event: InputEvent, _shape_idx: int) -> void:
	if event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
			get_viewport().set_input_as_handled() 
			emit_stats()

func emit_stats() -> void:
	if stats:
		print(stats.enemy_name)
		if has_node("/root/GlobalData"):
			GlobalData.select_enemy(stats)
	else:
		print("give me stats bitch fuck you die my tummy hurts")
