extends Node2D

@onready var alarm_sound = $Sounds/Alarm

@export var chat: Resource = preload("res://Scripts/chat.gd")

var story_beat = GlobalData.story_beat
var declared_beat: int = 0
var current_state: Dictionary = {}

var current_interactable: String = ""

func _ready() -> void:
	check_story_beat()
	if declared_beat == 2 and alarm_sound:
		alarm_sound.set("parameters/looping", true)
		alarm_sound.play()

func _process(_delta: float) -> void:
	pass

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("interact") and declared_beat == 2 and current_interactable != "":
		_trigger_object_interaction(current_interactable)

func _trigger_object_interaction(node_name: String) -> void:
	match node_name:
		"Bed":
			click_bed()
		"Alarm":
			turn_off_alarm()
		"Locker":
			check_locker()
		"Door":
			leave_room()

func click_bed() -> void:
	print("Made Bed")

func check_story_beat():
	declared_beat = int(GlobalData.story_beat)

func turn_off_alarm():
	if alarm_sound:
		alarm_sound.stop()

func leave_room():
	if declared_beat == 2:
		declared_beat = 2
		GlobalData.story_beat = "3.5"
		SceneManager.change_scene("res://Scenes/hallway.tscn", { "pattern": "diagonal" })

func check_locker():
	if declared_beat == 2:
		print("You looked at a picture :) you look great :)")

func _on_button_pressed() -> void:
	declared_beat = 2 
	if alarm_sound:
		alarm_sound.set("parameters/looping", true)
		alarm_sound.play()

func _is_player(body: Node2D) -> bool:
	return body is CharacterBody2D or body.is_in_group("Player") or body.name.to_lower().contains("player")

func _on_bed_body_entered(body: Node2D) -> void:
	if _is_player(body):
		current_interactable = "Bed"

func _on_alarm_body_entered(body: Node2D) -> void:
	if _is_player(body):
		current_interactable = "Alarm"

func _on_locker_body_entered(body: Node2D) -> void:
	if _is_player(body):
		current_interactable = "Locker"

func _on_door_body_entered(body: Node2D) -> void:
	if _is_player(body):
		current_interactable = "Door"

func _on_bed_body_exited(body: Node2D) -> void:
	if _is_player(body) and current_interactable == "Bed":
		current_interactable = ""

func _on_alarm_body_exited(body: Node2D) -> void:
	if _is_player(body) and current_interactable == "Alarm":
		current_interactable = ""

func _on_locker_body_exited(body: Node2D) -> void:
	if _is_player(body) and current_interactable == "Locker":
		current_interactable = ""

func _on_door_body_exited(body: Node2D) -> void:
	if _is_player(body) and current_interactable == "Door":
		current_interactable = ""
