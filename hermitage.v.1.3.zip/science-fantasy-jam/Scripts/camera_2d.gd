extends Camera2D

@export var max_pan_distance: Vector2 = Vector2(0, 0)
@export var smooth_speed: float = 5.0

func _process(delta: float) -> void:
	var viewport_size = get_viewport_rect().size
	var mouse_pos = get_viewport().get_mouse_position()
	
	var offset_normalized = Vector2(
		(mouse_pos.x - viewport_size.x / 2) / (viewport_size.x / 2),
		(mouse_pos.y - viewport_size.y / 2) / (viewport_size.y / 2)
	)
	
	var target_position = Vector2(
		offset_normalized.x * max_pan_distance.x,
		offset_normalized.y * max_pan_distance.y
	)
	
	offset = offset.lerp(target_position, smooth_speed * delta)
