extends CharacterBody2D

const SPEED = 400.0

@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D 

func _physics_process(delta: float) -> void:
	var direction := Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
	
	if direction != Vector2.ZERO:
		velocity = direction * SPEED
		play_walk_animation(direction)
	else:
		velocity = velocity.move_toward(Vector2.ZERO, SPEED)
		play_idle_animation()

	move_and_slide()

func play_walk_animation(dir: Vector2) -> void:
	var angle = rad_to_deg(dir.angle())
	
	if angle > -22.5 and angle <= 22.5:
		sprite.play("walk_right")
	elif angle > 22.5 and angle <= 67.5:
		sprite.play("walk_down_right")
	elif angle > 67.5 and angle <= 112.5:
		sprite.play("walk_down")
	elif angle > 112.5 and angle <= 157.5:
		sprite.play("walk_down_left")
	elif angle > 157.5 || angle <= -157.5:
		sprite.play("walk_left")
	elif angle > -157.5 and angle <= -112.5:
		sprite.play("walk_up_left")
	elif angle > -112.5 and angle <= -67.5:
		sprite.play("walk_up")
	elif angle > -67.5 and angle <= -22.5:
		sprite.play("walk_up_right")

func play_idle_animation() -> void:
	sprite.play("Idle")
