extends Node

@export var target_layer: TileMapLayer
@export var highlight_color: Color = Color(0.549, 0.392, 0.082, 0.588)
@export var alternate_color: Color = Color(0.231, 0.467, 1.0, 0.671)
@export var input_action_name: String = "HoverTrigger"

var active_indicators: Array[Polygon2D] = []

func _input(event: InputEvent) -> void:
	if not is_instance_valid(target_layer):
		return
		
	if event.is_action_pressed(input_action_name):
		light_up_all_cells()
	elif event.is_action_released(input_action_name):
		clear_all_indicators()

func light_up_all_cells() -> void:
	clear_all_indicators()
	
	if not target_layer.tile_set:
		return

	var used_cells = target_layer.get_used_cells()
	var tile_size = target_layer.tile_set.tile_size
	
	var half_x = tile_size.x / 2.0
	var half_y = tile_size.y / 2.0
	
	var points = PackedVector2Array([
		Vector2(0, -half_y),
		Vector2(half_x, 0),
		Vector2(0, half_y),
		Vector2(-half_x, 0)
	])

	for cell in used_cells:
		var indicator = Polygon2D.new()
		indicator.polygon = points
		
		if (cell.x + cell.y) % 2 == 0:
			indicator.color = highlight_color
		else:
			indicator.color = alternate_color
		
		target_layer.add_child(indicator)
		indicator.position = target_layer.map_to_local(cell)
		
		active_indicators.append(indicator)

func clear_all_indicators() -> void:
	for indicator in active_indicators:
		if is_instance_valid(indicator):
			indicator.queue_free()
	active_indicators.clear()
