extends Node2D

@onready var load_button: Button = $ColorRect/VBoxContainer/Button
@onready var action_button_2: Button = $ColorRect/VBoxContainer/Button2
@onready var save_button: Button = $ColorRect/VBoxContainer/Button3

@export var save_data : SaveGame 

func _ready() -> void:
	if save_data == null:
		save_data = SaveGame.new()
	save_data.debug_get_data()



func _on_button_pressed() -> void:
	save_data.save_game()


func _on_button_2_pressed() -> void:
	save_data.load_game()
	


func _on_button_3_pressed() -> void:
	save_data.clear_save()
