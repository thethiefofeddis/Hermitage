extends Control

var data: Array[float] = []: 
	set(value): 
		data = value
		_update_stats_labels()
		queue_redraw()

@export var preview_pilot_resource: Resource = null 
@export var current_enemy_resource: Resource = null 

@onready var right_arm = $"Graphics/Player/Text/Right Arm"
@onready var left_arm = $"Graphics/Player/Text/Left Arm"
@onready var right_leg = $"Graphics/Player/Text/Right Leg"
@onready var left_leg = $"Graphics/Player/Text/Left Leg"
@onready var head = $Graphics/Player/Text/Head
@onready var torso = $Graphics/Player/Text/Torso

@onready var enemy_right_arm = $"Graphics/Enemy/Text/Right Arm"
@onready var enemy_left_arm = $"Graphics/Enemy/Text/Left Arm"
@onready var enemy_right_leg = $"Graphics/Enemy/Text/Right Leg"
@onready var enemy_left_leg = $"Graphics/Enemy/Text/Left Leg"
@onready var enemy_head = $Graphics/Enemy/Text/Head
@onready var enemy_torso = $Graphics/Enemy/Text/Torso

@onready var graph_node = $Graphics/Workshop
@onready var bot = $Graphics/Player
@onready var enemy_node = $Graphics/Enemy
@onready var status_label = $Graphics/Enemy/StatusLabel

var current_tab: int = 0

func _ready() -> void:
	if Engine.is_editor_hint():
		if has_node("/root/GlobalData") and GlobalData.all_pilots.is_empty():
			GlobalData.load_pilots_from_directory("res://Resourses/Pilots/")
	
	update_data_from_pilot()
	
	if has_node("/root/GlobalData"):
		if not GlobalData.is_connected("pilot_changed", _on_pilot_changed):
			GlobalData.connect("pilot_changed", _on_pilot_changed)
			
		if not GlobalData.is_connected("enemy_selected", _on_enemy_selected):
			GlobalData.connect("enemy_selected", _on_enemy_selected)
			
	_set_tab_state(0)

func _update_stats_labels() -> void:
	var target_head = enemy_head if current_tab == 1 else head
	if not target_head:
		return
		
	var labels = []
	if current_tab == 1:
		labels = [enemy_right_arm, enemy_left_arm, enemy_right_leg, enemy_left_leg, enemy_head, enemy_torso]
	else:
		labels = [right_arm, left_arm, right_leg, left_leg, head, torso]
		
	if data.is_empty() or data.size() < 6:
		for lbl in labels:
			if lbl: lbl.text = "--"
		return
		
	if labels[0]: labels[0].text = "%.1f" % data[0]
	if labels[1]: labels[1].text = "%.1f" % data[1]
	if labels[2]: labels[2].text = "%.1f" % data[2]
	if labels[3]: labels[3].text = "%.1f" % data[3]
	if labels[4]: labels[4].text = "%.1f" % data[4]
	if labels[5]: labels[5].text = "%.1f" % data[5]

func update_data_from_pilot() -> void:
	var current_pilot = null
	
	if not Engine.is_editor_hint() and has_node("/root/GlobalData"):
		var selected_name = GlobalData.selected_pilot_name
		
		if "all_pilots" in GlobalData and GlobalData.all_pilots != null:
			for pilot in GlobalData.all_pilots:
				if pilot and pilot.pilot_name.strip_edges().to_lower() == selected_name.strip_edges().to_lower():
					current_pilot = pilot
					break
	
	if not current_pilot and preview_pilot_resource:
		current_pilot = preview_pilot_resource
	
	if current_pilot:
		data = [ 
			current_pilot.Right_Arm, 
			current_pilot.Left_Arm, 
			current_pilot.Right_Leg, 
			current_pilot.Left_Leg, 
			current_pilot.Head, 
			current_pilot.Torso 
		]
	else:
		data = []

func _on_pilot_changed() -> void:
	if current_tab == 0:
		update_data_from_pilot()

func _on_enemy_selected(enemy_stats: Enemy_Data) -> void:
	select_enemy(enemy_stats)

func select_enemy(enemy_resource: Resource) -> void:
	current_enemy_resource = enemy_resource
	_set_tab_state(1)

func _update_enemy_view() -> void:
	if not current_enemy_resource:
		status_label.text = "No Enemy Selected"
		data = [] 
		return
		
	data = [
		float(current_enemy_resource.Right_Arm),
		float(current_enemy_resource.Left_Arm),
		float(current_enemy_resource.Right_Leg),
		float(current_enemy_resource.Left_Leg),
		float(current_enemy_resource.Head),
		float(current_enemy_resource.Torso)
	]
	
	status_label.text = current_enemy_resource.enemy_name

func _set_tab_state(tab_index: int) -> void:
	current_tab = tab_index
	
	graph_node.visible = (tab_index == 2)
	bot.visible = (tab_index == 0)
	enemy_node.visible = (tab_index == 1)
	
	if tab_index == 0:
		update_data_from_pilot()
	elif tab_index == 1:
		_update_enemy_view()

func _on_bot_pressed() -> void:
	_set_tab_state(0)

func _on_enemy_pressed() -> void:
	_set_tab_state(1)

func _on_stats_pressed() -> void:
	_set_tab_state(2)
