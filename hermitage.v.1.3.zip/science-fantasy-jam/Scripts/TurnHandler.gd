extends Node

signal turn_number 

var current_turn: int = 0
