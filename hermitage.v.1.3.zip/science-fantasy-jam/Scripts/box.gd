extends Area2D

@export var player_node: CharacterBody2D
@export var enemy_node: CharacterBody2D
