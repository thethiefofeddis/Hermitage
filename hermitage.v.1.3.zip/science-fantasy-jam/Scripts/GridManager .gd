extends Node
class_name GridManager

@export var layer0: TileMapLayer
@export var layer1: TileMapLayer
@export var layer2: TileMapLayer

func get_occupied_tiles(ignore_node: Node = null) -> Dictionary:
	var occupied: Dictionary = {}
	
	if not is_instance_valid(layer0):
		return occupied
		
	for child in get_children():
		if child == ignore_node:
			continue
		if child is CanvasItem and not child.visible:
			continue
			
		var local_pos = layer0.to_local(child.global_position)
		var tile_pos = layer0.local_to_map(local_pos)
		occupied[tile_pos] = child
		
	return occupied

func is_tile_occupied(tile: Vector2i, ignore_node: Node = null) -> bool:
	if is_instance_valid(layer1):
		var tile_data = layer1.get_cell_tile_data(tile)
		if tile_data and tile_data.get_custom_data("solid") == true:
			return true
	if is_instance_valid(layer2):
		var tile_data = layer2.get_cell_tile_data(tile)
		if tile_data and tile_data.get_custom_data("solid") == true:
			return true
	return get_occupied_tiles(ignore_node).has(tile)
