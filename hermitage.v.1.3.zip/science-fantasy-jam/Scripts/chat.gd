extends Control

@export var player_name: String
@export var current_story_beat_ex: String = "" 

@onready var dialogue_json = preload("res://Json/start.json") 
@onready var ez_dialogue = get_node_or_null("EzDialogue")
@onready var node = $"."
@onready var state = {
	"show_only_one": false,
	"player_name_var": "",
	"name_var": 0,
	"juni_feel": 0,
	"duo_feel": 0,
	"is_talking": 0,
	"upper": false,
	"to_next_scene": 0, 
	"current_story_beat": "",
	"player_title_var": 0,
	"player_title": ""
}

var story_displayed: String = ""
var declared_story: int = 0 
var is_loading_dialogue: bool = false

func _ready() -> void: 
	if ez_dialogue:
		if not ez_dialogue.end_of_dialogue_reached.is_connected(_on_dialogue_ended):
			ez_dialogue.end_of_dialogue_reached.connect(_on_dialogue_ended)
			
	node.visible = false
	if not GlobalData.name_changed.is_connected(_on_global_name_changed): 
		GlobalData.name_changed.connect(_on_global_name_changed) 
	if not GlobalData.story_beat_changed.is_connected(_on_global_story_beat_changed): 
		GlobalData.story_beat_changed.connect(_on_global_story_beat_changed) 
	
	player_name = GlobalData.main_name 
	
	await get_tree().process_frame
	
	current_story_beat_ex = str(GlobalData.story_beat) 
	state["player_name_var"] = player_name 
	state["current_story_beat"] = current_story_beat_ex 
	story_displayed = current_story_beat_ex 
	
	var current_beat_str = str(GlobalData.story_beat)
	if current_beat_str == "1" or current_beat_str == "3":
		set_story_beat()
	else:
		if dialogue_json and ez_dialogue: 
			is_loading_dialogue = true
			node.visible = true
			ez_dialogue.start_dialogue(dialogue_json, state) 
			is_loading_dialogue = false

	set_title()
	pause_under_chat()

func _process(_delta: float) -> void: 
	pass 

func _on_global_name_changed() -> void: 
	player_name = GlobalData.main_name 
	state["player_name_var"] = player_name

func _on_global_story_beat_changed() -> void: 
	if current_story_beat_ex == str(GlobalData.story_beat):
		return
	current_story_beat_ex = str(GlobalData.story_beat) 
	state["current_story_beat"] = current_story_beat_ex 
	story_displayed = current_story_beat_ex 
	set_story_beat() 

func _on_ez_dialogue_dialogue_generated(response: DialogueResponse) -> void: 
	$Chatbox.clear_box() 
	if $Chatbox.has_method("update_ui_from_state"): 
		$Chatbox.update_ui_from_state(state) 
	
	var final_text := response.text 
	if state["upper"]: 
		final_text = final_text.to_upper() 
	
	$Chatbox.add_text(final_text) 
	for choice in response.choices: 
		$Chatbox.add_choice(choice) 

func _on_ez_dialogue_custom_signal_received(value: String) -> void: 
	if is_loading_dialogue:
		return
		
	var raw_params: PackedStringArray = value.split(",") 
	if raw_params.size() < 3: 
		return 
	
	var params: Array[String] = []
	for p in raw_params:
		params.append(p.strip_edges())
		
	if params[0] != "set": 
		return 
	
	var variable_name := params[1] 
	var variable_value := params[2] 
	
	if variable_name == "upper": 
		state["upper"] = (variable_value.to_lower() == "true") 
		return 
		
	var parsed_value: Variant 
	if variable_value.is_valid_int(): 
		parsed_value = variable_value.to_int() 
	else: 
		parsed_value = variable_value 

	if variable_name == "current_story_beat": 
		var incoming_beat := str(parsed_value).to_int()
		var historical_beat := str(GlobalData.story_beat).to_int()
		
		if incoming_beat < historical_beat:
			parsed_value = str(historical_beat) 
		else:
			if str(GlobalData.story_beat) != str(parsed_value):
				GlobalData.set_story_beat(str(parsed_value))

	if state.has(variable_name): 
		state[variable_name] = parsed_value 
		
	match variable_name: 
		"player_name_var": 
			update_player_name(str(parsed_value)) 
		"name_var": 
			if state["name_var"] == 4: 
				update_player_name("Juniper") 

	set_title()

func update_player_name(new_name: String) -> void: 
	player_name = new_name 
	state["player_name_var"] = new_name 
	GlobalData.set_name_player(new_name) 

func check_story_beat() -> void: 
	var beat_text := str(GlobalData.story_beat) 
	if beat_text.is_valid_int(): 
		var beat := beat_text.to_int() 
		if beat <= 0: 
			set_story_beat() 
	else:
		set_story_beat()

func set_story_beat() -> void: 
	if not ez_dialogue or is_loading_dialogue:
		return
		
	is_loading_dialogue = true
	var current_beat_str = str(GlobalData.story_beat)
	
	if current_beat_str == "1":
		node.visible = true
		ez_dialogue.start_dialogue(dialogue_json, state, "Start")
	elif current_beat_str == "3":
		node.visible = true
		ez_dialogue.start_dialogue(dialogue_json, state, "Udom Talk Intro (3)")
	else: 
		declared_story = 0
		node.visible = false
	is_loading_dialogue = false

func _on_dialogue_ended() -> void:
	node.visible = false

func pause_under_chat():
	if node.visible:
		var current = get_tree().current_scene
		print (current)
		if not current:
			return
		var is_chat = current.scene_file_path == "res://chat.tscn" or current.name == "chat"
		
		if is_chat:
			get_tree().paused = true
			print("Paused (In Chat)")
		else:
			get_tree().paused = false
			print("Not Paused (Outside Chat)")

func set_title():
	if not ez_dialogue:
		return
	if state["player_title_var"] == 1:
		state["player_title"] = "Sword"
	elif state["player_title_var"] == 2:
		state["player_title"] = "Cog"
	elif state["player_title_var"] == 3:
		state["player_title"] = "DEBUG"
