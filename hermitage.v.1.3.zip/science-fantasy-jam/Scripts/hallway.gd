extends Node2D

@onready var charas: Node2D = $Charas
@onready var chat_ui: Control = $"Chat UI"

func _ready() -> void:
	chat_ui.visible = false

func _process(delta: float) -> void:
	toggle_characters_process()

func toggle_characters_process() -> void:
	if chat_ui.visible:
		charas.process_mode = PROCESS_MODE_DISABLED
	else:
		charas.process_mode = PROCESS_MODE_INHERIT
