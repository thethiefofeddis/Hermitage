class_name CardUI
extends PanelContainer

@export var card_data: CardData : set = _set_card_data

@onready var name_label: Label = $NameLabel
@onready var cost_label: Label = $CostLabel
@onready var des_label: Label = $DescriptionLabel
@onready var art_rect: TextureRect = $ArtTextureRect
@onready var tween: Tween
@onready var card_area: Area2D = $Area2D 

var initial_position: Vector2 = Vector2.ZERO
var initial_rotation: float = 0.0

var is_dragging: bool = false
var drag_offset: Vector2 = Vector2.ZERO

func _set_card_data(new_data: CardData) -> void:
	card_data = new_data
	if not is_node_ready(): 
		await ready
	if card_data:
		name_label.text = card_data.card_name
		des_label.text = card_data.description
		cost_label.text = str(card_data.cost)
		art_rect.texture = card_data.card_texture
	else:
		name_label.text = ""
		cost_label.text = ""
		art_rect.texture = null

func _ready() -> void:
	center_pivot_offset()
	initial_position = position
	initial_rotation = rotation

func center_pivot_offset() -> void:
	pivot_offset = size / 2.0

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_LEFT:
			if event.pressed:
				is_dragging = true
				drag_offset = get_global_mouse_position() - global_position
				if tween and tween.is_running():
					tween.kill()
			else:
				is_dragging = false
				check_drop_zone()

func _process(_delta: float) -> void:
	if is_dragging:
		global_position = get_global_mouse_position() - drag_offset

#registry
func check_drop_zone() -> void:
	var is_valid_drop: bool = false
	var overlapping_areas = card_area.get_overlapping_areas()
	for area in overlapping_areas:
		if area.name == "PlayArea":
			is_valid_drop = true
			break
	if is_valid_drop:
		print(card_data.card_name, " successfully played!") 
		if card_data and "dash" in card_data.card_name.to_lower():
			GlobalData.is_dash_card_pending = true
		get_rid_of_card()
		if card_data and "strike" in card_data.card_name.to_lower():
			GlobalData.is_strike_card_pending = true
		get_rid_of_card()
		if card_data and "block" in card_data.card_name.to_lower():
			GlobalData.is_block_card_pending = true
		get_rid_of_card()
		if card_data and "fortify" in card_data.card_name.to_lower():
			GlobalData.is_fortify_card_pending = true
		get_rid_of_card()
		if card_data and "overheat" in card_data.card_name.to_lower():
			GlobalData.is_overheat_card_pending = true
		get_rid_of_card()
		if card_data and "soar" in card_data.card_name.to_lower():
			GlobalData.is_soar_card_pending = true
		get_rid_of_card()
	else:
		snap_back_to_hand()

func snap_back_to_hand() -> void:
	tween = create_tween()
	tween.tween_property(self, "position", initial_position, 0.3).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	tween.parallel().tween_property(self, "rotation", initial_rotation, 0.3).set_trans(Tween.TRANS_QUAD)

func get_rid_of_card():
	queue_free()

func play_card():
	pass
