extends Node

signal pilot_changed
signal name_changed
signal story_beat_changed
signal pilot_stats_updated
signal movement_card_played(card: CardData)
signal attack_card_played(card: CardData)
signal skill_card_played(card: CardData) 
signal card_played(card_name: String)
signal enemy_selected(enemy_stats: Enemy_Data)



var is_dash_card_pending: bool = false
var is_strike_card_pending: bool = false
var is_block_card_pending: bool = false
var is_fortify_card_pending: bool = false
var is_overheat_card_pending: bool = false
var is_soar_card_pending: bool = false

var active_hovered_card: CardData = null
var is_card_range_preview_active: bool = false

@onready var setting_scene: PackedScene = preload("res://Scenes/settings.tscn") 

@export var simon_stats: Resource
@export var kaito_stats: Resource
@export var julia_stats: Resource

var movement_handler: Node2D = null
var chat_script = preload("res://Scripts/chat.gd") 
var main_name: String = "Juni" 
var timer: float = 12.0
var timer_label: Label
var selected_pilot_name: String = "N/A" 
var all_pilots: Array = []
var story_beat: String = "1" 
var simon_current_stats
var pilot_stats_changed: Dictionary = {}
var current_turn_number = 0

func _ready() -> void:
	load_pilots_from_directory("res://Resources/Pilots/") 

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("Pause"): 
		var current_scene_path = get_tree().current_scene.scene_file_path
		if current_scene_path != "res://Scenes/settings.tscn": 
			SceneManager.change_scene("res://Scenes/settings.tscn", { "pattern": "diagonal" }) 

func load_pilots_from_directory(path: String) -> void:
	if not path.ends_with("/"): 
		path += "/"
	var dir = DirAccess.open(path)
	if dir:
		dir.list_dir_begin()
		var file_name = dir.get_next()
		while file_name != "":
			if not dir.current_is_dir():
				if file_name.ends_with(".tres") or file_name.ends_with(".tres.remap"): 
					var clean_path = path + file_name.replace(".remap", "") 
					var res = load(clean_path)
					if res is Resource: 
						all_pilots.append(res)
						
						if "simon" in file_name.to_lower():
							simon_stats = res
						elif "kaito" in file_name.to_lower():
							kaito_stats = res
						elif "julia" in file_name.to_lower():
							julia_stats = res
							
			file_name = dir.get_next()
		dir.list_dir_end()
	else:
		print("Failed to open path: ", path)

func update_timer_display() -> void:
	if timer_label != null:
		timer_label.text = str(timer)

func modify_timer(amount: float) -> void:
	if timer <= 0:
		pass
	else:
		timer += amount
	update_timer_display()

func set_pilot(new_p_name: String) -> void:
	selected_pilot_name = new_p_name
	pilot_changed.emit()
	get_pilot_stats()

func set_name_player(new_name: String) -> void:
	main_name = new_name
	name_changed.emit()

func set_story_beat(new_sb: String) -> void:
	story_beat = new_sb
	story_beat_changed.emit()

func get_pilot_stats() -> Dictionary:
	pilot_stats_changed = {}
	
	var targets = {
		"Simon Sodew": simon_stats,
		"Kaito Tres": kaito_stats,
		"Julia Fey": julia_stats
	}
	
	for pilot_key in targets:
		var res = targets[pilot_key]
		if res != null:
			pilot_stats_changed[pilot_key] = {
				"heat": res.heat,
				"shields": res.shields,
				"mobility": res.mobility,
				"power": res.power,
				"scanners": res.scanners
			}
		else:
			pilot_stats_changed[pilot_key] = {
				"heat": 0.0,
				"shields": 0.0,
				"mobility": 0.0,
				"power": 0.0,
				"scanners": 0.0
			}
			
	pilot_stats_updated.emit()
	return pilot_stats_changed

func select_enemy(enemy_stats: Enemy_Data) -> void:
	enemy_selected.emit(enemy_stats)
