@tool
extends Node2D

@export_group("Chart Settings")
@export var radius: float = 150.0: 
	set(value): 
		radius = value 
		queue_redraw()

@export var max_stat_value: float = 1.0: 
	set(value):
		max_stat_value = value
		queue_redraw()

@export_group("Colors")
@export var graph_color: Color = Color(0.2, 0.8, 0.2, 0.6): 
	set(value): 
		graph_color = value 
		queue_redraw()

@export_group("Fallback Helper")
@export var preview_pilot_resource: Resource:
	set(value):
		preview_pilot_resource = value
		update_data_from_pilot()

@export var outer_frame_color: Color = Color(0.3, 0.3, 0.3, 0.2): 
	set(value): 
		outer_frame_color = value 
		queue_redraw()

@export_group("Node References")
@export var dial_node_path: NodePath = NodePath(""):
	set(value):
		dial_node_path = value
		if is_inside_tree():
			dial_node = get_node_or_null(dial_node_path)

var dial_node: Node2D = null
var data: Array[float] = []: 
	set(value): 
		data = value 
		queue_redraw()

func _ready() -> void: 
	if not dial_node_path.is_empty():
		dial_node = get_node_or_null(dial_node_path)

	if Engine.is_editor_hint():
		if has_node("/root/GlobalData") and GlobalData.all_pilots.is_empty():
			GlobalData.load_pilots_from_directory("res://Resourses/Pilots/")
			
	update_data_from_pilot()
	
	if has_node("/root/GlobalData") and GlobalData.has_signal("pilot_changed"):
		if not GlobalData.is_connected("pilot_changed", _on_pilot_changed):
			GlobalData.connect("pilot_changed", _on_pilot_changed)

func update_data_from_pilot() -> void: 
	var current_pilot = null

	if not Engine.is_editor_hint() and has_node("/root/GlobalData"):
		var selected_name = GlobalData.selected_pilot_name
		if "all_pilots" in GlobalData and GlobalData.all_pilots != null:
			for pilot in GlobalData.all_pilots:
				if pilot and pilot.pilot_name.strip_edges().to_lower() == selected_name.strip_edges().to_lower():
					current_pilot = pilot
					break

	if not current_pilot and preview_pilot_resource:
		current_pilot = preview_pilot_resource

	if current_pilot: 
		data = [ 
			current_pilot.heat, 
			current_pilot.shields, 
			current_pilot.mobility, 
			current_pilot.power, 
			current_pilot.scanners 
		]
	else: 
		data = []

func _on_pilot_changed() -> void: 
	update_data_from_pilot()

func _draw() -> void: 
	if data.is_empty(): 
		return 

	var num_points = data.size()
	var outer_points: PackedVector2Array = [] 
	var graph_points: PackedVector2Array = [] 

	for i in range(num_points): 
		var angle = (i * 2 * PI / num_points) - PI / 2 
		
		var outer_p = Vector2(cos(angle), sin(angle)) * radius 
		outer_points.append(outer_p) 
		
		var normalized_value = data[i] / max_stat_value
		var current_radius = radius * clamp(normalized_value, 0.0, 1.0) 
		
		var graph_p = Vector2(cos(angle), sin(angle)) * current_radius 
		graph_points.append(graph_p) 

	if outer_points.size() > 2: 
		draw_polygon(outer_points, [outer_frame_color]) 
		
		var line_points = outer_points.duplicate()
		line_points.append(outer_points[0]) 
		draw_polyline(line_points, Color(1, 1, 1, 0.3), 2.0) 

	if graph_points.size() > 2: 
		draw_polygon(graph_points, [graph_color]) 
		
		var graph_line_points = graph_points.duplicate()
		graph_line_points.append(graph_points[0]) 
		draw_polyline(graph_line_points, Color(graph_color.r, graph_color.g, graph_color.b, 1.0), 1.5)

	for p in outer_points: 
		draw_line(Vector2.ZERO, p, Color(1, 1, 1, 0.15), 1.0)

func _on_stat_decrease_pressed() -> void: 
	if not Engine.is_editor_hint() and has_node("/root/GlobalData"):
		var selected_name = GlobalData.selected_pilot_name 
		if "all_pilots" in GlobalData and GlobalData.all_pilots != null: 
			for pilot in GlobalData.all_pilots: 
				if pilot and pilot.pilot_name.strip_edges().to_lower() == selected_name.strip_edges().to_lower(): 
					pilot.heat = maxf(pilot.heat - 0.1, 0.0) 
					break 
	elif preview_pilot_resource:
		preview_pilot_resource.heat = maxf(preview_pilot_resource.heat - 0.1, 0.0)
		
	update_data_from_pilot()

func simon_dial() -> void:
	if not dial_node or not dial_node.has_method("angle_to_number"):
		return

	var current_pilot = null 
	
	if not Engine.is_editor_hint() and has_node("/root/GlobalData"):
		var selected_name = GlobalData.selected_pilot_name 
		if "all_pilots" in GlobalData and GlobalData.all_pilots != null: 
			for pilot in GlobalData.all_pilots: 
				if pilot and pilot.pilot_name.strip_edges().to_lower() == selected_name.strip_edges().to_lower(): 
					current_pilot = pilot 
					break 
					
	if not current_pilot and preview_pilot_resource: 
		current_pilot = preview_pilot_resource 
		
	if current_pilot: 
		var dial_val: float = dial_node.angle_to_number()
		
		current_pilot.mobility = dial_val * max_stat_value
		current_pilot.power = (1.0 - dial_val) * max_stat_value
		
		update_data_from_pilot()

func _process(_delta: float) -> void:
	simon_dial()
