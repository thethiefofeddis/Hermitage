extends Node

@export var pilot_1: Files
@export var pilot_2: Files
@export var pilot_3: Files
@export var active_mission: Missions
@export var debug_label: Label

# Avrages the score of the pilots and the misson (p/m), adds it,/5, and then multiplies the lowest score
func _ready() -> void:
	if active_mission:
		var total_score = 0.0
		var active_pilots = 0.0
		var output_text = ""
		
		if pilot_1:
			var score = calculate_mission_success_score(pilot_1, active_mission)
			print("Pilot 1 Chance of Success: ", snappedf(score, 0.1), "%")
			output_text += "Pilot 1: " + str(snappedf(score, 0.1)) + "%\n"
			total_score += score
			active_pilots += 1.0
		if pilot_2:
			var score = calculate_mission_success_score(pilot_2, active_mission)
			print("Pilot 2 Chance of Success: ", snappedf(score, 0.1), "%")
			output_text += "Pilot 2: " + str(snappedf(score, 0.1)) + "%\n"
			total_score += score
			active_pilots += 1.0
		if pilot_3:
			var score = calculate_mission_success_score(pilot_3, active_mission)
			print("Pilot 3 Chance of Success: ", snappedf(score, 0.1), "%")
			output_text += "Pilot 3: " + str(snappedf(score, 0.1)) + "%\n"
			total_score += score
			active_pilots += 1.0
			
		if active_pilots > 0.0:
			var final_score = total_score / active_pilots
			print("Final Squad Chance of Success: ", snappedf(final_score, 0.1), "%")
			output_text += "\nFinal Squad: " + str(snappedf(final_score, 0.1)) + "%"
			
			if debug_label:
				debug_label.text = output_text
			else:
				print("Label is not assigned in the inspector!")

func calculate_mission_success_score(file: Files, mission: Missions) -> float:
	if not file: 
		return 0.0
		
	var stat_keys = ["heat", "shields", "mobility", "power", "scanners"]
	var total_s = 0.0
	var lowest_s = 1.0
	
	for key in stat_keys:
		var file_val = float(file.get(key))
		var mission_val = float(mission.get(key))
		var s = file_val / mission_val if mission_val != 0.0 else 1.0
		
		s = minf(s, 1.0)
		total_s += s
		lowest_s = minf(lowest_s, s)
		
	var average_s = total_s / 5.0
	return average_s * lowest_s * 100.0
