extends Node2D

@export var chat_ui_path: NodePath

@onready var chat_ui = get_node_or_null(chat_ui_path)

var declared_beat: int = 0
var current_interactable: String = ""

func _ready() -> void:
	check_story_beat()

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("interact") and current_interactable != "":
		_trigger_object_interaction(current_interactable)

func _trigger_object_interaction(node_name: String) -> void:
	match node_name:
		"Udom":
			talk_to_udom()

func talk_to_udom() -> void:
	if chat_ui:
		chat_ui.visible = true
		GlobalData.set_story_beat("3")
	else:
		GlobalData.set_story_beat("3")

func check_story_beat() -> void:
	declared_beat = int(GlobalData.story_beat)

func _is_player(body: Node2D) -> bool:
	return body is CharacterBody2D or body.is_in_group("Player") or body.name.to_lower().contains("player")

func _on_udom_body_entered(body: Node2D) -> void:
	if _is_player(body):
		current_interactable = "Udom"

func _on_udom_body_exited(body: Node2D) -> void:
	if _is_player(body) and current_interactable == "Udom":
		current_interactable = ""
