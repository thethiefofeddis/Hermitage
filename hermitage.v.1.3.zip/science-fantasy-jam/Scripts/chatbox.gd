extends Node2D

@onready var choice_button_scene = preload("res://Scenes/ChoiceButton.tscn")
@onready var Name_Line: LineEdit = $"../ColorRect/VBoxContainer/Name"
@onready var Text_Box: Label = $"../ColorRect/VBoxContainer/Label"
@onready var V_Box: VBoxContainer = $"../ColorRect/VBoxContainer"

const NAME_VAR = "name_var"
const JUNI_FEEL = "juni_feel"
const DUO_FEEL = "duo_feel"
const IS_TALKING = "is_talking"
const DUO_IS_TALKING = "duo_is_talking"
const TO_NEXT_SCENE = "to_next_scene"

var choice_buttons: Array[Button] = []
var current_state: Dictionary = {}

func _ready() -> void:
	if has_node("../ColorRect/VBoxContainer/Name"):
		Name_Line.visible = false

func update_ui_from_state(new_state: Dictionary) -> void:
	current_state = new_state
	name_yourself()
	juni_feels()
	duo_feels()
	juni_is_talking()
	duo_is_talking()
	to_the_next_scene()

func clear_box() -> void:
	Text_Box.text = ""
	for choice in choice_buttons:
		if is_instance_valid(choice) and choice.get_parent() == V_Box:
			V_Box.remove_child(choice)
			choice.queue_free()
	choice_buttons = []

func add_text(text: String) -> void:
	Text_Box.text = text

func add_choice(choice_text: String) -> void:
	var button_obj = choice_button_scene.instantiate()
	button_obj.choice_index = choice_buttons.size()
	choice_buttons.push_back(button_obj)
	button_obj.text = choice_text
	button_obj.choice_selected.connect(_on_choice_selected)
	V_Box.add_child(button_obj)

func _on_choice_selected(choice_index: int) -> void:
	if NAME_VAR in current_state and int(current_state[NAME_VAR]) == 5:
		_on_name_text_submitted(Name_Line.text)
		return
		
	if Name_Line.visible:
		_on_name_text_submitted(Name_Line.text)
		return
		
	var ez_dialogue = get_node_or_null("../EzDialogue")
	if ez_dialogue != null:
		ez_dialogue.next(choice_index)

func name_yourself() -> void:
	if NAME_VAR in current_state:
		var current_val = int(current_state[NAME_VAR])
		match current_val:
			2:
				choose_your_own_name()
			3, 4, 5:
				if has_node("../ColorRect/VBoxContainer/Name"):
					Name_Line.visible = false

func submit_data(text_input: String) -> void:
	pass

func choose_your_own_name() -> void:
	if has_node("../ColorRect/VBoxContainer/Name"):
		Name_Line.visible = true
		Name_Line.grab_focus()

func _on_name_text_submitted(new_text: String) -> void:
	var clean_text = new_text.strip_edges()
	if clean_text == "":
		clean_text = "Juniper"
		
	if has_node("../ColorRect/VBoxContainer/Name"):
		Name_Line.visible = false
		Name_Line.text = ""
		
	if get_parent() != null and get_parent().has_method("update_player_name"):
		get_parent().update_player_name(clean_text)
		
	var ez_dialogue = get_node_or_null("../EzDialogue")
	if ez_dialogue != null:
		ez_dialogue.next(0)

func juni_feels() -> void:
	if JUNI_FEEL in current_state:
		var current_val = int(current_state[JUNI_FEEL])
		var juni_sprite = get_node_or_null("../Charaters/Main/Juni")
		if juni_sprite:
			match current_val:
				1: juni_sprite.play("N")
				2: juni_sprite.play("H")
				3: juni_sprite.play("S")
				4: juni_sprite.play("M")

func duo_feels() -> void:
	if DUO_FEEL in current_state:
		var current_val = int(current_state[DUO_FEEL])
		var duo_sprite = get_node_or_null("../Charaters/Main/Juni2")
		if duo_sprite:
			match current_val:
				1: duo_sprite.play("N")
				2: duo_sprite.play("H")
				3: duo_sprite.play("S")
				4: duo_sprite.play("M")

func juni_is_talking() -> void:
	if IS_TALKING in current_state:
		var current_val = int(current_state[IS_TALKING])
		var juni_sprite = get_node_or_null("../Charaters/Main/Juni")
		if juni_sprite:
			match current_val:
				1: juni_sprite.modulate = Color(0.261, 0.25, 0.278, 1.0)
				2: juni_sprite.modulate = Color(1.0, 1.0, 1.0, 1.0)

func duo_is_talking() -> void:
	if DUO_IS_TALKING in current_state:
		var current_val = int(current_state[DUO_IS_TALKING])
		var duo_sprite = get_node_or_null("../Charaters/Main/Juni2")
		if duo_sprite:
			match current_val:
				1: duo_sprite.modulate = Color(0.261, 0.25, 0.278, 1.0)
				2: duo_sprite.modulate = Color(1.0, 1.0, 1.0, 1.0)

func to_the_next_scene() -> void:
	if TO_NEXT_SCENE in current_state:
		var current_val = int(current_state[TO_NEXT_SCENE])
		if current_val == 1:
			SceneManager.change_scene("res://Scenes/bunks.tscn", { "pattern": "diagonal" })
		elif current_val == 4:
			SceneManager.change_scene("res://Scenes/files.tscn", { "pattern": "diagonal" })
