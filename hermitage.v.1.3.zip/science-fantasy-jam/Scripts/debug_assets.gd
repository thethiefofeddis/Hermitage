extends Node2D

@export_category("UI References")
@export var pilot_labels: Array[Label]
@export var pilot_buttons: Array[Button]

var file_slots: Array[Files] = [null, null, null]

func _ready() -> void:
	for i in range(pilot_buttons.size()):
		pilot_buttons[i].pressed.connect(_on_pilot_pressed.bind(i))
	
	change_file_in_slot(0, "res://Resources/Pilots/SimonSodewFile.tres")
	change_file_in_slot(1, "res://Resources/Pilots/KaitoTresFile.tres")
	change_file_in_slot(2, "res://Resources/Pilots/Julia Fey.tres")

func change_file_in_slot(slot_index: int, resource_path: String) -> void:
	if not ResourceLoader.exists(resource_path):
		push_error("Path missing: " + resource_path)
		return
	
	var new_file = load(resource_path) as Files
	if slot_index < file_slots.size():
		file_slots[slot_index] = new_file
		update_single_display(pilot_labels[slot_index], file_slots[slot_index])
	else:
		push_error("Invalid slot index: " + str(slot_index))

func update_single_display(target_label: Label, data: Files) -> void:
	if not target_label: return
	
	if not data:
		target_label.text = ""
		return
		
	target_label.text = (
		"Pilot: " + data.pilot_name + "\n" +
		"Squadron: " + data.squadron + "\n" +
		"\"" + data.ship_name + "\"\n\n" +
		"Heat: " + str(data.heat) + "\n" +
		"Shields: " + str(data.shields) + "\n" +
		"Mobility: " + str(data.mobility) + "\n" +
		"Power: " + str(data.power) + "\n" +
		"Scanners: " + str(data.scanners) + "\n\n" +
		"Description:\n" + data.description
	)

func _on_pilot_pressed(slot_index: int) -> void:
	var selected_pilot = file_slots[slot_index]
	if selected_pilot:
		GlobalData.set_pilot(selected_pilot.pilot_name)
		SceneManager.change_scene("res://Scenes/Card Game Scenes/board.tscn", { "pattern": "diagonal" })
