extends Control

@export var card_ui_scene: PackedScene
@export var hand_cards_data: Array[CardData] = []

@export var hand_radius: float = 500.0
@export var max_spread_angle: float = 30.0
@export var card_scale: Vector2 = Vector2(0.6, 0.6) 

func _ready() -> void:
	populate_hand()

func populate_hand() -> void:
	for data in hand_cards_data:
		var card_instance = card_ui_scene.instantiate() as CardUI
		add_child(card_instance)
		card_instance.card_data = data

	
	await get_tree().process_frame
	update_hand_layout()

func update_hand_layout() -> void:
	var cards: Array[CardUI] = []
	for child in get_children():
		if child is CardUI:
			cards.append(child)
			
	var card_count: int = cards.size()
	if card_count == 0:
		return
		
	var angle_spread_rad: float = deg_to_rad(max_spread_angle)
	var center_offset: Vector2 = Vector2(0, hand_radius)
	
	for i in range(card_count):
		var card = cards[i]
		var angle: float = 0.0
		
		if card_count > 1:
			angle = -angle_spread_rad / 2.0 + (float(i) / (card_count - 1)) * angle_spread_rad
			
		var target_pos: Vector2 = Vector2(
			hand_radius * sin(angle),
			-hand_radius * cos(angle)
		) + center_offset
		
		card.scale = card_scale
		card.pivot_offset = card.size / 2.0
		card.position = target_pos - (card.pivot_offset * card_scale)
		card.rotation = angle
		
		card.initial_position = card.position
		card.initial_rotation = card.rotation

func _on_card_played(card_instance: CardUI) -> void:
	var data = card_instance.card_data
	
	if data.type == CardData.CardType.MOVEMENT:
		GlobalData.movement_card_played.emit(data)
		
	card_instance.queue_free()
	await get_tree().process_frame
	update_hand_layout()
