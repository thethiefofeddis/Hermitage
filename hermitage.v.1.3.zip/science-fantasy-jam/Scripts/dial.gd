extends Node2D

@onready var graphics_node = $Graphics/Bg/Dial
@onready var knob_dial = $Graphics/Bg/Cover
@onready var middle_point = $Graphics/Bg 

var following: bool = false
var touched: bool = false
var angle_offset: float = 0.0 
const max_dist: float = 70.0 

const MID_ANGLE: float = -PI / 2 
const MAX_DEVIATION: float = PI / 2 

func _ready() -> void:
	graphics_node.rotation = MID_ANGLE - MAX_DEVIATION

func _physics_process(_delta: float) -> void:
	var mouse_pos := get_global_mouse_position()
	var dial_pos: Vector2 = graphics_node.global_position
	var mouse_dist := mouse_pos.distance_squared_to(dial_pos)
	
	if Input.is_action_just_pressed("Click"):
		if mouse_dist < (max_dist * max_dist):
			following = true
			touched = true
			var mouse_angle := (mouse_pos - dial_pos).angle()
			angle_offset = graphics_node.rotation - mouse_angle
			
	if Input.is_action_just_released("Click"):
		following = false

	if following:
		var current_mouse_angle := (mouse_pos - dial_pos).angle()
		var target_rotation := current_mouse_angle + angle_offset
		var angle_difference := wrapf(target_rotation - MID_ANGLE, -PI, PI)
		var clamped_deviation := clampf(angle_difference, -MAX_DEVIATION, MAX_DEVIATION)
		graphics_node.rotation = MID_ANGLE + clamped_deviation

func angle_to_number() -> float:
	var left_bound : float = MID_ANGLE - MAX_DEVIATION
	var current_progress : float = graphics_node.rotation - left_bound
	var raw_val: float = clampf(current_progress / PI, 0.0, 1.0)
	return snappedf(raw_val, 0.1)
