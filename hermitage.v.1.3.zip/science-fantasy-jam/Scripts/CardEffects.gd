extends Control

@export_category("Attack Cards")
@export var Attack_Cards: Array[Resource] = []
@export_category("Skill Cards")
@export var Skill_Cards: Array[Resource] = []
@export_category("Power Cards")
@export var Power_Cards: Array[Resource] = []
@export_category("Movement Cards")
@export var Movement_Cards: Array[Resource] = []

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
