extends Node2D

signal spot_attacked(attack_tile_position: Vector2i)
signal player_spot_occupied (tile_position: Vector2i)

@export var layer0: TileMapLayer
@export var layer1: TileMapLayer
@export var player: CharacterBody2D
@export var speed: float = 150.0

@export_category("UI References")
@export var movement_labels: Array[Label]
@export var heat_labels: Array[Label]
@export_category("UI References")
@export var end_turn_buttons: Array[Button]

@onready var hand_node = $"../Hand Man"
@onready var EnemyMovementClass = load("res://Scripts/debug_enemy.gd")
@onready var enemy_movement = EnemyMovementClass.new()
const MOBILITY_COST_MULTIPLIER: float = 0.1
const POWER_COST_MULTIPLIER: float = 0.1

var current_pilot = ""

var hover_effect: Polygon2D
var target_position: Vector2 = Vector2.ZERO
var is_moving: bool = false
var current_tile_pos: Vector2i = Vector2i.ZERO

# Stats
var max_mobility: float = 0.0
var current_mobility: float = 0.0
var max_power: float = 0.0
var current_power: float = 0.0
var max_shields: float = 0.0
var current_shields: float = 0.0
var max_heat: float = 0.0
var current_heat: float = 0.0

# is_active
var is_dash_active: bool = false
var is_strike_active: bool = false
var is_block_active: bool = false
var is_overheat_active: bool = false 
var is_soar_active: bool = false 

var active_range_indicators: Array[Polygon2D] = []
var last_calculated_tile: Vector2i = Vector2i(-999, -999)
var current_path: Array[Vector2i] = []
var last_turn_observed: int = 0
var fortify_signal: int = 0
var soar_multiplier: int = 2 #(Double movement)

func _ready() -> void:
	GlobalData.movement_handler = self
	await get_tree().process_frame
	current_pilot = GlobalData.selected_pilot_name
	initialize_mobility()
	determine_movement()
	setup_hover_polygon()
	max_stats_at_start()
	heat_label_tag()

	
	if is_instance_valid(player):
		target_position = player.global_position
	if is_instance_valid(layer0):
		current_tile_pos = layer0.local_to_map(layer0.to_local(player.global_position))

	player_spot_occupied.emit(current_tile_pos)

	for button in end_turn_buttons:
		if is_instance_valid(button) and not button.pressed.is_connected(_on_end_turn_pressed):
			button.pressed.connect(_on_end_turn_pressed)

func find_bfs_path(start: Vector2i, target: Vector2i) -> Array[Vector2i]:
	var empty_path: Array[Vector2i] = []
	if start == target:
		var single_path: Array[Vector2i] = [start]
		return single_path
		
	var used_cells = layer0.get_used_cells()
	if not used_cells.has(target):
		return empty_path

	var occupied_tiles = {}
	var parent_node = get_parent()
	if parent_node and parent_node.has_method("get_occupied_tiles"):
		occupied_tiles = parent_node.get_occupied_tiles(self)

	var start_path: Array[Vector2i] = [start]
	var queue: Array = [ [start, start_path] ]
	var visited: Dictionary = { start: true }
	var directions = [Vector2i.UP, Vector2i.DOWN, Vector2i.LEFT, Vector2i.RIGHT]
	
	while queue.size() > 0:
		var current_element: Array = queue.pop_front()
		var current_cell: Vector2i = current_element[0]
		var path_so_far: Array[Vector2i] = current_element[1]
		
		if current_cell == target:
			return path_so_far
			
		for dir in directions:
			var neighbor = current_cell + dir
			
			if not visited.has(neighbor) and used_cells.has(neighbor):
				if occupied_tiles.has(neighbor) and neighbor != target:
					continue
					
				visited[neighbor] = true
				var new_path: Array[Vector2i] = path_so_far.duplicate()
				new_path.append(neighbor)
				queue.append([neighbor, new_path])
				
	return empty_path

func _process(_delta: float) -> void:
	if not is_instance_valid(layer0):
		return
		
	if GlobalData.is_dash_card_pending:
		GlobalData.is_dash_card_pending = false
		heat_label_tag()
		activate_dash_selection()
		handle_hover_effect()
		
	if GlobalData.is_strike_card_pending:
		GlobalData.is_strike_card_pending = false
		heat_label_tag()
		activate_strike_selection()
		handle_hover_effect()
	
	if GlobalData.is_block_card_pending:
		GlobalData.is_block_card_pending = false
		current_shields += 0.1
		print ("Current shield = " , current_shields , " Max is = ", max_shields)
		is_block_active = false
		heat_label_tag()

	
	if GlobalData.is_fortify_card_pending:
		GlobalData.is_fortify_card_pending = false
		fortify_signal += 1
		print("Fortify Played, 2 block next turn, signal is ", fortify_signal)
		heat_label_tag()

	
	if GlobalData.is_overheat_card_pending:
		GlobalData.is_overheat_card_pending = false
		activate_overheat_selection()
		handle_hover_effect()
		heat_label_tag()

	if GlobalData.is_soar_card_pending:
		GlobalData.is_soar_card_pending = false
		activate_soar_selection()
		handle_hover_effect()
		heat_label_tag()

	

func _physics_process(_delta: float) -> void:
	if is_moving and is_instance_valid(player):
		move_player()

func _input(event: InputEvent) -> void:

	if is_moving:
		return
		
	if event is InputEventMouseMotion:
		handle_hover_effect()
		
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
		if not is_instance_valid(layer0) or not is_instance_valid(player):
			return
			
		var mouse_global_pos = get_global_mouse_position()
		var target_tile_pos = layer0.local_to_map(layer0.to_local(mouse_global_pos))
		
		if not layer0.get_used_cells().has(target_tile_pos):
			return
			
		if is_dash_active:
			var parent_node = get_parent()
			var is_target_occupied = false
			if parent_node and parent_node.has_method("is_tile_occupied"):
				is_target_occupied = parent_node.is_tile_occupied(target_tile_pos, self)
				
			if is_target_occupied:
				print("Cannot dash there! That spot is already occupied.")
				return

			var path = find_bfs_path(current_tile_pos, target_tile_pos)
			var path_distance = path.size() - 1 if not path.is_empty() else 999
			var mobility_cost = snappedf(path_distance * MOBILITY_COST_MULTIPLIER, 0.01)
			
			if path.is_empty():
				print("No path available or fully blocked by enemy!")
			elif path_distance > 0 and (current_mobility >= mobility_cost or is_equal_approx(current_mobility, mobility_cost)):
				var success = execute_dash(path)
				if success:
					is_dash_active = false
					clear_range_indicators()
					get_viewport().set_input_as_handled()
			else:
				print("Selected tile is out of mobility range! Cost: ", mobility_cost, " Available: ", current_mobility)

		elif is_strike_active:
			var distance = calculate_tile_distance(current_tile_pos, target_tile_pos)
			var power_cost = snappedf(distance * MOBILITY_COST_MULTIPLIER, 0.01)
			
			if distance > 0 and (current_power >= power_cost or is_equal_approx(current_power, power_cost)):
				print("Strike executed at cell: ", target_tile_pos)
				spot_attacked.emit(target_tile_pos)
				is_strike_active = false
				clear_range_indicators()
				get_viewport().set_input_as_handled()
			else:
				print("Selected tile is out of power range! Cost: ", power_cost, " Available: ", current_power)

		elif is_overheat_active:
			var distance = calculate_tile_distance(current_tile_pos, target_tile_pos)
			var power_cost = snappedf(distance * MOBILITY_COST_MULTIPLIER, 0.01)
			
			if distance > 0 and (current_power >= power_cost or is_equal_approx(current_power, power_cost)):
				print("Overheat executed at cell: ", target_tile_pos)
				current_shields -= 0.2
				print("Current shields are ", current_shields)
				spot_attacked.emit(target_tile_pos)
				is_overheat_active = false
				clear_range_indicators()
				get_viewport().set_input_as_handled()
			else:
				print("Selected tile is out of range! Cost: ", power_cost, " Available: ", current_power)
		elif is_soar_active:
			print("active")
			var parent_node = get_parent()
			var is_target_occupied = false
			if parent_node and parent_node.has_method("is_tile_occupied"):
				is_target_occupied = parent_node.is_tile_occupied(target_tile_pos, self)
				
			if is_target_occupied:
				print("Cannot soar there! That spot is already occupied.")
				return

			var path = find_bfs_path(current_tile_pos, target_tile_pos)
			var path_distance = path.size() - 1 if not path.is_empty() else 999
			var mobility_cost = snappedf(path_distance * MOBILITY_COST_MULTIPLIER, 0.01)
			
			var boosted_mobility = current_mobility * soar_multiplier
			
			if path.is_empty():
				print("No path available or fully blocked by enemy!")
			elif path_distance > 0 and (boosted_mobility >= mobility_cost or is_equal_approx(boosted_mobility, mobility_cost)):
				var success = execute_soar(path)
				if success:
					is_soar_active = false
					clear_range_indicators()
					get_viewport().set_input_as_handled()
			else:
				print("Selected tile is out of mobility range! Cost: ", mobility_cost, " Available (Boosted): ", boosted_mobility)
func activate_dash_selection() -> void:
	is_dash_active = true
	is_strike_active = false
	last_calculated_tile = Vector2i(-999, -999)
	print("Dash selection mode active! Choose a tile within mobility capacity.")

func activate_soar_selection() -> void:
	is_soar_active = true
	last_calculated_tile = Vector2i(-999, -999)
	print("Soar selection mode active! Choose a tile within mobility capacity.")
	
func activate_strike_selection() -> void:
	is_strike_active = true
	is_dash_active = false
	last_calculated_tile = Vector2i(-999, -999)
	print("Power selection mode active! Choose a tile within mobility capacity.")

func activate_overheat_selection() -> void:
	is_overheat_active = true
	is_strike_active = false
	is_dash_active = false
	last_calculated_tile = Vector2i(-999, -999)
	print("Choose a tile within capacity.")
	
func execute_dash(calculated_path: Array[Vector2i]) -> bool:
	if not is_instance_valid(layer0) or not is_instance_valid(player) or is_moving:
		return false
	if calculated_path.is_empty():
		return false
		
	var path_distance = calculated_path.size() - 1
	var mobility_cost = snappedf(path_distance * MOBILITY_COST_MULTIPLIER, 0.01)
	
	if current_mobility < mobility_cost and not is_equal_approx(current_mobility, mobility_cost):
		print("Not enough mobility to dash!")
		return false
		
	current_mobility = clampf(snappedf(current_mobility - mobility_cost, 0.01), 0.0, max_mobility)
	determine_movement()
	
	current_path = calculated_path.duplicate()
	current_path.pop_front() 
	
	advance_path_movement()
	return true

func execute_soar(calculated_path: Array[Vector2i]) -> bool:
	if not is_instance_valid(layer0) or not is_instance_valid(player) or is_moving:
		return false
	if calculated_path.is_empty():
		return false
		
	var path_distance = calculated_path.size() - 1
	var mobility_cost = snappedf(path_distance * MOBILITY_COST_MULTIPLIER, 0.01)
	
	var boosted_mobility = current_mobility * soar_multiplier
	
	if boosted_mobility < mobility_cost and not is_equal_approx(boosted_mobility, mobility_cost):
		print("Not enough mobility to soar!")
		return false
		
	current_mobility = clampf(snappedf(boosted_mobility - mobility_cost, 0.01), 0.0, max_mobility)
	determine_movement()
	
	current_path = calculated_path.duplicate()
	current_path.pop_front() 
	
	advance_path_movement()
	return true




func advance_path_movement() -> void:
	if current_path.is_empty():
		is_moving = false
		player_spot_occupied.emit(current_tile_pos)
		return
		
	current_tile_pos = current_path.pop_front()
	target_position = layer0.to_global(layer0.map_to_local(current_tile_pos))
	is_moving = true

func calculate_tile_distance(start: Vector2i, end: Vector2i) -> int:
	var diff = end - start
	return abs(diff.x) + abs(diff.y)

func move_player() -> void:
	var direction = player.global_position.direction_to(target_position)
	player.velocity = direction * speed
	player.move_and_slide()
	
	if player.global_position.distance_to(target_position) < 4.0:
		player.global_position = target_position
		player.velocity = Vector2.ZERO
		advance_path_movement()

func setup_hover_polygon() -> void:
	hover_effect = Polygon2D.new()
	hover_effect.polygon = PackedVector2Array([
		Vector2(0, -8),
		Vector2(16, 0),
		Vector2(0, 8),
		Vector2(-16, 0)
	])
	hover_effect.color = Color(1, 1, 1, 0.4)
	hover_effect.visible = false
	add_child(hover_effect)

func handle_hover_effect() -> void:
	if not is_instance_valid(layer0):
		return
		
	var mouse_global_pos = get_global_mouse_position()
	var hovered_tile = layer0.local_to_map(layer0.to_local(mouse_global_pos))
	
	if hovered_tile == last_calculated_tile:
		return
	last_calculated_tile = hovered_tile

	clear_range_indicators()

	if not (is_dash_active or is_strike_active or is_overheat_active or is_soar_active):
		if is_instance_valid(hover_effect):
			hover_effect.visible = false
		return

	if not layer0.get_used_cells().has(hovered_tile):
		if is_instance_valid(hover_effect):
			hover_effect.visible = false
		return

	var tile_global_pos = layer0.to_global(layer0.map_to_local(hovered_tile))

	if is_overheat_active:
		var distance = calculate_tile_distance(current_tile_pos, hovered_tile)
		var power_cost = snappedf(distance * MOBILITY_COST_MULTIPLIER, 0.01)
		
		if distance > 0 and (current_power >= power_cost or is_equal_approx(current_power, power_cost)):
			if is_instance_valid(hover_effect):
				hover_effect.global_position = tile_global_pos
				hover_effect.color = Color(0.0, 0.685, 0.501, 0.5)
				hover_effect.visible = true
		else:
			if is_instance_valid(hover_effect):
				hover_effect.global_position = tile_global_pos
				hover_effect.color = Color(0.954, 0.0, 0.546, 0.5)
				hover_effect.visible = true

	elif is_strike_active:
		var distance = calculate_tile_distance(current_tile_pos, hovered_tile)
		var power_cost = snappedf(distance * MOBILITY_COST_MULTIPLIER, 0.01)
		
		if distance > 0 and (current_power >= power_cost or is_equal_approx(current_power, power_cost)):
			if is_instance_valid(hover_effect):
				hover_effect.global_position = tile_global_pos
				hover_effect.color = Color(0.0, 0.631, 0.457, 0.5)
				hover_effect.visible = true
		else:
			if is_instance_valid(hover_effect):
				hover_effect.global_position = tile_global_pos
				hover_effect.color = Color(0.956, 0.0, 0.53, 0.5)
				hover_effect.visible = true

	elif is_dash_active:
		var parent_node = get_parent()
		var is_target_occupied = false
		if parent_node and parent_node.has_method("is_tile_occupied"):
			is_target_occupied = parent_node.is_tile_occupied(hovered_tile, self)
			
		if is_target_occupied:
			if is_instance_valid(hover_effect):
				hover_effect.visible = false
			return

		var path = find_bfs_path(current_tile_pos, hovered_tile)
		var path_distance = path.size() - 1 if not path.is_empty() else 999
		var mobility_cost = snappedf(path_distance * MOBILITY_COST_MULTIPLIER, 0.01)
		
		if not path.is_empty() and path_distance > 0 and (current_mobility >= mobility_cost or is_equal_approx(current_mobility, mobility_cost)):
			if is_instance_valid(hover_effect):
				hover_effect.global_position = tile_global_pos
				hover_effect.color = Color(0.0, 0.631, 0.04, 0.5)
				hover_effect.visible = true
		else:
			if is_instance_valid(hover_effect):
				hover_effect.global_position = tile_global_pos
				hover_effect.color = Color(0.954, 0.0, 0.546, 0.5)
				hover_effect.visible = true

	elif is_soar_active:
		var parent_node = get_parent()
		var is_target_occupied = false
		if parent_node and parent_node.has_method("is_tile_occupied"):
			is_target_occupied = parent_node.is_tile_occupied(hovered_tile, self)
			
		if is_target_occupied:
			if is_instance_valid(hover_effect):
				hover_effect.visible = false
			return

		var path = find_bfs_path(current_tile_pos, hovered_tile)
		var path_distance = path.size() - 1 if not path.is_empty() else 999
		var mobility_cost = snappedf(path_distance * MOBILITY_COST_MULTIPLIER, 0.01)
		
		var boosted_mobility = current_mobility * soar_multiplier
		
		if not path.is_empty() and path_distance > 0 and (boosted_mobility >= mobility_cost or is_equal_approx(boosted_mobility, mobility_cost)):
			if is_instance_valid(hover_effect):
				hover_effect.global_position = tile_global_pos
				hover_effect.color = Color(0.0, 0.631, 0.04, 0.5)
				hover_effect.visible = true
		else:
			if is_instance_valid(hover_effect):
				hover_effect.global_position = tile_global_pos
				hover_effect.color = Color(0.954, 0.0, 0.546, 0.5)
				hover_effect.visible = true


#card tiles
func draw_dash_tiles() -> void:
	for cell in layer0.get_used_cells():
		var dist = calculate_tile_distance(current_tile_pos, cell)
		var cost = snappedf(dist * MOBILITY_COST_MULTIPLIER, 0.01)
		var can_afford = current_mobility >= cost or is_equal_approx(current_mobility, cost)
		if dist > 0 and can_afford:
			create_indicator_at(cell, Color(0, 1, 0, 0.25))

func draw_strike_tiles() -> void:
	for cell in layer0.get_used_cells():
		var dist = calculate_tile_distance(current_tile_pos, cell)
		var cost = snappedf(dist * MOBILITY_COST_MULTIPLIER, 0.01)
		var can_afford = current_power >= cost or is_equal_approx(current_power, cost)
		if dist > 0 and can_afford:
			create_indicator_at(cell, Color(0.613, 0.122, 0.186, 0.25))

#making Indicators
func create_indicator_at(cell: Vector2i, color_to_use: Color) -> void:
	var indicator = Polygon2D.new()
	indicator.polygon = hover_effect.polygon
	indicator.color = color_to_use
	indicator.global_position = layer0.to_global(layer0.map_to_local(cell))
	add_child(indicator)
	active_range_indicators.append(indicator)

func clear_range_indicators() -> void:
	for indicator in active_range_indicators:
		if is_instance_valid(indicator):
			indicator.queue_free()
	active_range_indicators.clear()

#Moving
func initialize_mobility() -> void:
	var stats = GlobalData.get_pilot_stats()
	var cleaned_search = current_pilot.to_lower()
	for pilot_key in stats.keys():
		if cleaned_search in pilot_key.to_lower() or pilot_key.to_lower() in cleaned_search:
			var pilot_dict = stats[pilot_key]
			if pilot_dict.has("mobility"):
				max_mobility = float(pilot_dict["mobility"])
			elif pilot_dict.has("Mobility"):
				max_mobility = float(pilot_dict["Mobility"])
				
			if pilot_dict.has("power"):
				max_power = float(pilot_dict["power"])
			elif pilot_dict.has("Power"):
				max_power = float(pilot_dict["Power"])
			
			if pilot_dict.has("shields"):
				max_shields = float(pilot_dict["shields"])
			elif pilot_dict.has("Shields"):
				max_shields = float(pilot_dict["Shields"])
			
			if pilot_dict.has("heat"):
				max_heat = float(pilot_dict["heat"])
			elif pilot_dict.has("Heat"):
				max_heat = float(pilot_dict["Heat"])
	current_mobility = max_mobility
	current_power = max_power

#Labels
func determine_movement() -> void:
	for label in movement_labels:
		if is_instance_valid(label):
			label.text = "Mobility: %1.1f / %1.1f" % [current_mobility, max_mobility]



func heat_label_tag():
	for label in heat_labels:
		if is_instance_valid(label):
			label.text = "Heat: %1.1f / %1.1f" % [current_heat, max_heat]


#Turn

func _on_end_turn_pressed() -> void:
	GlobalData.current_turn_number += 1
	current_mobility = max_mobility
	current_power = max_power
	is_dash_active = false
	is_strike_active = false
	determine_movement()
	play_fortify()
	heat_label_tag()

func max_stats_at_start():
	current_shields = max_shields
	current_heat = max_heat

func play_fortify():
	for i in range(fortify_signal):
		fortify_signal = 0
		#print("Fortify Applied, signal is ", fortify_signal)
		current_shields += 0.2
		print("Current shields are ", current_shields)
