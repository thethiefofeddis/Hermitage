extends Node2D

@onready var button_pressed_player = $"../../Effects/Audio/Click"
@onready var button_hover_player = $"../../Effects/Audio/Hover"
@onready var logo_player = $"../../Effects/Audio/ClickLogo"
@onready var mech_player = $"../../Effects/Audio/ClickMech"
@onready var crash_player = $"../../Effects/Audio/Crash"
@onready var goodbye_player = $"../../Effects/Audio/Goodbye"

@onready var right_foot = $"../Legs/Leg4"
@onready var right_foot_2 = $"../Legs/Legs2/Leg4"


var f1_base_pos: Vector2
var f2_base_pos: Vector2
var is_initialized: bool = false


func _on_start_pressed() -> void:
	button_pressed_player.play()
	SceneManager.change_scene("res://Scenes/intro_scene.tscn", { "pattern": "diagonal" })
	


func _on_settings_pressed() -> void:
	button_pressed_player.play()
	SceneManager.change_scene("res://Scenes/settings.tscn", { "pattern": "diagonal" })


func _on_quit_pressed() -> void:
	goodbye_player.play()
	play_and_wait()
	




func _on_start_mouse_entered() -> void:
	button_hover_player.play()


func _on_settings_mouse_entered() -> void:
	button_hover_player.play()



func _on_quit_mouse_entered() -> void:
	button_hover_player.play()


func _on_area_2d_input_event(viewport: Node, event: InputEvent, shape_idx: int) -> void:
	if event is InputEventMouseButton and event.is_pressed() and event.button_index == MOUSE_BUTTON_LEFT:
		logo_player.play()


func _on_area_2d_input_event2(viewport: Node, event: InputEvent, shape_idx: int) -> void:
	if event is InputEventMouseButton and event.is_pressed() and event.button_index == MOUSE_BUTTON_LEFT:
		mech_player.play()
		play_stomp_animation(right_foot, right_foot_2)


func play_stomp_animation(foot1: Sprite2D, foot2: Sprite2D) -> void:
	if not is_initialized:
		f1_base_pos = foot1.position
		f2_base_pos = foot2.position
		is_initialized = true

	var tween = create_tween()
	
	tween.tween_property(foot1, "position:y", f1_base_pos.y - 40, 0.15).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	tween.parallel().tween_property(foot2, "position:y", f2_base_pos.y - 40, 0.15).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	
	tween.tween_property(foot1, "position:y", f1_base_pos.y, 0.08).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	tween.parallel().tween_property(foot2, "position:y", f2_base_pos.y, 0.08).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	
	tween.tween_callback(func(): crash_player.play())

func play_and_wait():
	goodbye_player.play()
	await goodbye_player.finished
	get_tree().quit()
