extends Node2D

@export var player_name: String
@export var dialogue_json: JSON

@onready var state = {
	"show_only_one": false,
	"player_name_var": player_name,
	"name_var": 0,
	"juni_feel" : 0
}

func _ready() -> void:
	($EzDialogue as EzDialogue).start_dialogue(dialogue_json, state)

func _process(_delta: float) -> void:
	pass

func _on_ez_dialogue_dialogue_generated(response: DialogueResponse) -> void:
	$Chatbox.clear_box()
	if $Chatbox.has_method("update_ui_from_state"):
		$Chatbox.update_ui_from_state(state)
	$Chatbox.add_text(response.text)
	for choice in response.choices:
		$Chatbox.add_choice(choice)

func _on_ez_dialogue_custom_signal_received(value: String) -> void:
	var params = value.split(",")
	
	if params.size() > 0 and params[0] == "set":
		var variable_name = params[1]
		var variable_value = params[2]
		
		if variable_value.is_valid_int():
			state[variable_name] = variable_value.to_int()
		else:
			state[variable_name] = variable_value
			
		if variable_name == "player_name_var":
			player_name = variable_value
			
		if variable_name == "name_var" and state["name_var"] == 4:
			update_player_name("Juniper")

func update_player_name(new_name: String) -> void:
	player_name = new_name
	state["player_name_var"] = new_name
