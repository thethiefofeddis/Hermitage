extends Resource
class_name Files

@export var heat: float = 0.0
@export var shields: float = 0.0
@export var mobility: float = 0.0
@export var power: float = 0.0
@export var scanners: float = 0.0
@export var pilot_name: String = ""
@export var ship_name: String = ""
@export var squadron: String = ""
@export var description: String = ""
