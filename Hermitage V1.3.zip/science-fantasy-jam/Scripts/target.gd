@tool 
extends Node2D

@export var radius: float = 150.0:
	set(value):
		radius = value
		queue_redraw()

@export var graph_color: Color = Color(0.2, 0.8, 0.2, 0.6):
	set(value):
		graph_color = value
		queue_redraw()

@export var outer_frame_color: Color = Color(0.3, 0.3, 0.3, 0.2):
	set(value):
		outer_frame_color = value
		queue_redraw()

@export var current_mission: Missions:
	set(value):
		if current_mission and current_mission.changed.is_connected(_on_mission_changed):
			current_mission.changed.disconnect(_on_mission_changed)
			
		current_mission = value
		
		if current_mission:
			if not current_mission.changed.is_connected(_on_mission_changed):
				current_mission.changed.connect(_on_mission_changed)
		
		update_data_from_mission()

var data: Array[float] = []:
	set(value):
		data = value
		queue_redraw()

func _ready() -> void:
	update_data_from_mission()

func update_data_from_mission() -> void:
	if current_mission:
		data = [
			current_mission.heat, 
			current_mission.shields, 
			current_mission.mobility, 
			current_mission.power, 
			current_mission.scanners
		]
	else:
		data = [0.8, 0.5, 0.9, 0.4, 0.7]
	queue_redraw()

func _on_mission_changed() -> void:
	update_data_from_mission()

func _draw() -> void:
	if data.is_empty(): 
		return
	
	var num_points = data.size()
	var outer_points: PackedVector2Array = []
	var graph_points: PackedVector2Array = []

	for i in range(num_points):
		var angle = (i * 2 * PI / num_points) - PI / 2 
		
		var outer_p = Vector2(cos(angle), sin(angle)) * radius
		outer_points.append(outer_p)
		
		var current_radius = radius * clamp(data[i], 0.0, 1.0) 
		var graph_p = Vector2(cos(angle), sin(angle)) * current_radius
		graph_points.append(graph_p)

	if outer_points.size() > 2:
		draw_polygon(outer_points, [outer_frame_color])
		
		var line_points = outer_points
		line_points.append(outer_points[0]) 
		draw_polyline(line_points, Color(1, 1, 1, 0.3), 2.0)

	if graph_points.size() > 2:
		var fill_points = graph_points
		fill_points.append(graph_points[0])
		draw_polygon(fill_points, [graph_color])

	for p in outer_points:
		draw_line(Vector2.ZERO, p, Color(1, 1, 1, 0.2), 1.5)
