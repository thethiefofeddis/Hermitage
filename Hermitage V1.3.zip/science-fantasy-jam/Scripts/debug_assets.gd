extends Node2D

@export var label_one: Label
@export var label_two: Label
@export var label_three: Label

@export var button_one: Button
@export var button_two: Button
@export var button_three: Button

var file_slot_1: Files
var file_slot_2: Files
var file_slot_3: Files

func _ready() -> void:
	change_file_in_slot(1, "res://Resourses/Pilots/SimonSodewFile.tres")
	change_file_in_slot(2, "res://Resourses/Pilots/KaitoTresFile.tres")


func change_file_in_slot(slot_number: int, resource_path: String) -> void:
	if not ResourceLoader.exists(resource_path):
		push_error("Path missing: " + resource_path)
		return
		
	var new_file = load(resource_path) as Files
	
	match slot_number:
		1:
			file_slot_1 = new_file
			update_single_display(label_one, file_slot_1)
		2:
			file_slot_2 = new_file
			update_single_display(label_two, file_slot_2)
		3:
			file_slot_3 = new_file
			update_single_display(label_three, file_slot_3)
		_:
			push_error("Invalid slot: " + str(slot_number))

func update_single_display(target_label: Label, data: Files) -> void:
	if not target_label:
		return
	if not data:
		target_label.text = ""
		return
		
	target_label.text = (
		"Pilot: " + data.pilot_name + "\n" +
		"Squadron: " + data.squadron + "\n" +
		"\"" + data.ship_name + "\"\n\n" +
		"Heat: " + str(data.heat) + "\n" +
		"Shields: " + str(data.shields) + "\n" +
		"Mobility: " + str(data.mobility) + "\n" +
		"Power: " + str(data.power) + "\n" +
		"Scanners: " + str(data.scanners) + "\n\n" +
		"Description:\n" + data.description
	)

func _on_pick_1_pressed() -> void:
	if file_slot_1:
		GlobalData.set_pilot(file_slot_1.pilot_name)
	SceneManager.change_scene("res://Scenes/workshop.tscn", { "pattern": "diagonal" })

func _on_pick_2_pressed() -> void:
	if file_slot_2:
		GlobalData.set_pilot(file_slot_2.pilot_name)
	SceneManager.change_scene("res://Scenes/workshop.tscn", { "pattern": "diagonal" })

func _on_pick_3_pressed() -> void:
	if file_slot_3:
		GlobalData.set_pilot(file_slot_3.pilot_name)
	SceneManager.change_scene("res://Scenes/workshop.tscn", { "pattern": "diagonal" })
