class_name ChoiceButton extends Button

# Tells what choice was chosen
var choice_index = 0

signal choice_selected(choice_index)

# Sends it out
func _on_pressed() -> void:
	choice_selected.emit(choice_index)
	pass # Replace with function body.
