extends Node

signal pilot_changed

var timer: float = 12
var timer_label: Label 
var selected_pilot_name: String = "No Pilot Selected"
var all_pilots: Array[Files] = []

func _ready() -> void:
	load_pilots_from_directory("res://Resourses/Pilots/")

func load_pilots_from_directory(path: String) -> void:
	if not path.ends_with("/"):
		path += "/"
		
	var dir = DirAccess.open(path)
	if dir:
		dir.list_dir_begin()
		var file_name = dir.get_next()
		while file_name != "":
			if not dir.current_is_dir():
				if file_name.ends_with(".tres") or file_name.ends_with(".tres.remap"):
					var clean_path = path + file_name.replace(".remap", "")
					var res = load(clean_path)
					if res is Files:
						all_pilots.append(res)
			file_name = dir.get_next()
		dir.list_dir_end()
	else:
		print("Failed to open path: ", path)

func update_timer_display() -> void:
	if timer_label != null:
		timer_label.text = str(timer)

func modify_timer(amount: float) -> void:
	if timer <= 0:
		pass
	else:
		timer += amount
		update_timer_display()

func set_pilot(new_name: String) -> void:
	selected_pilot_name = new_name
	pilot_changed.emit()
