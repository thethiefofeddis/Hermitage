extends Node2D

@export var debug_label: Label
@export var scene_timer_label: Label

func _ready() -> void:
	await get_tree().process_frame
	
	if scene_timer_label:
		GlobalData.timer_label = scene_timer_label
		GlobalData.update_timer_display()
	
	deploy()
	
	if debug_label:
		debug_label.text = GlobalData.selected_pilot_name  

func _on_debug_button_pressed() -> void:
	GlobalData.modify_timer(-1.0)
	deploy() 

func deploy():
	if GlobalData.timer <= 0:
		SceneManager.change_scene("res://Scenes/deployment.tscn", { "pattern": "diagonal" })
