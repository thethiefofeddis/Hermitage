extends Node2D



func _on_start_pressed() -> void:
	SceneManager.change_scene("res://Scenes/chat.tscn", { "pattern": "diagonal" })


func _on_settings_pressed() -> void:
	SceneManager.change_scene("res://Scenes/settings.tscn", { "pattern": "diagonal" })


func _on_quit_pressed() -> void:
	get_tree().quit()
