extends Node2D

@onready var choice_button_scene = preload("res://Scenes/ChoiceButton.tscn")
@onready var Name_Line = $VBoxContainer/Name
var choice_buttons: Array[Button] = []
var current_state: Dictionary = {}

func _ready():
	if has_node("VBoxContainer/Name"):
		Name_Line.visible = false
	

func update_ui_from_state(new_state: Dictionary):
	current_state = new_state
	name_yourself()
	juni_feels()
	duo_feels()
	juni_is_talking()
	duo_is_talking()

func clear_box():
	$VBoxContainer/Label.text = ""
	for choice in choice_buttons:
		if is_instance_valid(choice) and choice.get_parent() == $VBoxContainer:
			$VBoxContainer.remove_child(choice)
			choice.queue_free() 
	choice_buttons = []

func add_text(text: String):
	$VBoxContainer/Label.text = text
	
func add_choice(choice_text: String):
	var button_obj: ChoiceButton = choice_button_scene.instantiate()
	button_obj.choice_index = choice_buttons.size()
	choice_buttons.push_back(button_obj)
	button_obj.text = choice_text
	button_obj.choice_selected.connect(_on_choice_selected)
	$VBoxContainer.add_child(button_obj)

func _on_choice_selected(choice_index: int):
	if "name_var" in current_state and int(current_state["name_var"]) == 5:
		var current_text = Name_Line.text
		_on_name_text_submitted(current_text)
		return
		
	if Name_Line.visible:
		var current_text = Name_Line.text
		_on_name_text_submitted(current_text)
		return
		
	var ez_dialogue = get_node_or_null("../EzDialogue")
	if ez_dialogue != null:
		(ez_dialogue as EzDialogue).next(choice_index)

func name_yourself():
	if "name_var" in current_state:
		var current_val = int(current_state["name_var"])
		if current_val == 2:
			choose_your_own_name()
		elif current_val == 3:
			Name_Line.visible = false
		elif current_val == 4:
			if has_node("VBoxContainer/Name"):
				Name_Line.visible = false
		elif current_val == 5:
			Name_Line.visible = false

func submit_data(text_input: String) -> void:
	print("Submitted Text: ", text_input)
	
func choose_your_own_name():
	if has_node("VBoxContainer/Name"):
		Name_Line.visible = true
		Name_Line.grab_focus()

func _on_name_text_submitted(new_text: String) -> void:
	var clean_text = new_text.strip_edges()
	if clean_text == "":
		clean_text = "Juniper"
		
	if has_node("VBoxContainer/Name"):
		Name_Line.visible = false
		Name_Line.text = ""
	
	if get_parent() != null and get_parent().has_method("update_player_name"):
		get_parent().update_player_name(clean_text)
		
	var ez_dialogue = get_node_or_null("../EzDialogue")
	if ez_dialogue != null:
		(ez_dialogue as EzDialogue).next(0)

func juni_feels():
	if "juni_feel" in current_state:
		var current_val = int(current_state["juni_feel"])
		if current_val == 1:
			$"../Charaters/Main/Juni".play("N")
		elif current_val == 2:
			$"../Charaters/Main/Juni".play("H")
		elif current_val == 3:
			$"../Charaters/Main/Juni".play("S")
		elif current_val == 4:
			$"../Charaters/Main/Juni".play("M")

func duo_feels():
	if "duo_feel" in current_state:
		var current_val = int(current_state["duo_feel"])
		if current_val == 1:
			$"../Charaters/Main/Juni2".play("N")
		elif current_val == 2:
			$"../Charaters/Main/Juni2".play("H")
		elif current_val == 3:
			$"../Charaters/Main/Juni2".play("S")
		elif current_val == 4:
			$"../Charaters/Main/Juni2".play("M")

func juni_is_talking():
	if "is_talking" in current_state:
		var current_val = int(current_state["is_talking"])
		if current_val == 1:
			$"../Charaters/Main/Juni".modulate = Color(0.261, 0.25, 0.278, 1.0)
		elif current_val == 2:
			$"../Charaters/Main/Juni".modulate = Color(1.0, 1.0, 1.0, 1.0)


func duo_is_talking():
	if "duo_is_talking" in current_state:
		var current_val = int(current_state["duo_is_talking"])
		if current_val == 1:
			$"../Charaters/Main/Juni2".modulate = Color(0.261, 0.25, 0.278, 1.0)
		elif current_val == 2:
			$"../Charaters/Main/Juni2".modulate = Color(1.0, 1.0, 1.0, 1.0)
